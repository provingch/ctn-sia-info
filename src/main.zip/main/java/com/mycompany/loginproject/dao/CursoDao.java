/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginproject.dao;

import com.mycompany.loginproject.clases.conexion;
import com.mycompany.loginproject.model.Curso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jonat
 */
public class CursoDao extends conexion {

    public ArrayList<Curso> consultarCursos(int userId) throws SQLException {
        ArrayList<Curso> cursos = new ArrayList();
        String sql = "SELECT c.id, nombre AS especialidad, promocion, seccion "
                + "FROM curso c JOIN especialidad e ON c.especialidad_id = e.id "
                + "WHERE c.id IN (SELECT curso_id FROM planilla WHERE profesor_id = ?);";
        try (Connection con = getCon(); PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setInt(1, userId);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                int curso_id = rs.getInt("id");
                String especialidad = rs.getString("especialidad");
                int promocion = rs.getInt("promocion");
                String seccion = rs.getString("seccion");

                Curso c = new Curso(curso_id, especialidad, promocion, seccion);
                cursos.add(c);
            }
        }
        return cursos;
    }

    public Curso findById(int id) throws SQLException {
        String sql = "SELECT c.id, nombre AS especialidad, promocion, seccion "
                + "FROM curso c JOIN especialidad e ON c.especialidad_id = e.id "
                + "WHERE c.id = ?";
        try (Connection con = getCon(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return fromResultSet(rs);
            }
        }
    }

    public Curso fromResultSet(ResultSet rs) throws SQLException {
        if (rs.next()) {
            int curso_id = rs.getInt("id");
            String especialidad = rs.getString("especialidad");
            int promocion = rs.getInt("promocion");
            String seccion = rs.getString("seccion");

            Curso c = new Curso(curso_id, especialidad, promocion, seccion);
            return c;
        } else {
            return null;
        }
    }
}
